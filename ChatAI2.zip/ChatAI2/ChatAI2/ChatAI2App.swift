//
//  ChatAI2App.swift
//  ChatAI2
//
//  Created by Isaac Palmer on 12/13/22.
//

import SwiftUI

@main
struct ChatAI2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
